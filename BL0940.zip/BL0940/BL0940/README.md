# BL0940 Arduino Library

Arduino library for the **BL0940** single-phase energy metering IC by Shanghai Belling. Supports both UART and SPI communication modes.

## Features

- UART mode (4800 baud, default) with single-register and full-packet reads
- SPI mode (up to 900kHz, Mode 1) with checksum verification
- Measures: Voltage RMS, Current RMS, Active Power, Energy, Phase Angle, Power Factor
- Internal temperature sensor + external NTC support
- Over-current detection via Fast RMS
- Anti-creep (no-load) threshold
- Power and current RMS offset calibration registers
- Zero-crossing output (ZX pin)

## Wiring

### UART Mode (Default)

| BL0940 Pin | Connection |
|------------|------------|
| VDD (1) | 3.3V |
| GND (7) | GND |
| TX/SDO (13) | Arduino RX (needs pull-up) |
| RX/SDI (12) | Arduino TX |
| SEL (10) | GND |
| IP1/IN1 (3,4) | Through 1mΩ shunt |
| VP/VN (5,6) | Via voltage divider |
| VT (2) | Optional: NTC thermistor |

### SPI Mode

| BL0940 Pin | Connection |
|------------|------------|
| VDD (1) | 3.3V |
| GND (7) | GND |
| TX/SDO (13) | Arduino MISO |
| RX/SDI (12) | Arduino MOSI |
| SCLK (11) | Arduino SCK |
| SEL (10) | VDD (3.3V) |

## Quick Start

### UART Mode

```cpp
#include <BL0940.h>
#include <SoftwareSerial.h>

SoftwareSerial blSerial(2, 3);
BL0940 meter(blSerial);

void setup() {
    Serial.begin(115200);
    blSerial.begin(4800);
    meter.begin();
}

void loop() {
    Serial.print("V="); Serial.print(meter.getVoltage(), 1);
    Serial.print(" I="); Serial.print(meter.getCurrent(), 3);
    Serial.print(" P="); Serial.print(meter.getPower(), 1);
    Serial.print(" PF="); Serial.println(meter.getPowerFactor(), 2);
    delay(1000);
}
```

### SPI Mode

```cpp
#include <SPI.h>
#include <BL0940.h>

BL0940 meter(-1, 500000);

void setup() {
    Serial.begin(115200);
    meter.begin();
}

void loop() {
    Serial.print("V="); Serial.println(meter.getVoltage(), 1);
    delay(1000);
}
```

### Full Packet Read (UART, most efficient)

```cpp
BL0940_Data data;
if (meter.readAll(data)) {
    float v = meter.convertVoltage(data.v_rms);
    float i = meter.convertCurrent(data.i_rms);
    float p = meter.convertPower(data.watt);
    float t = meter.convertInternalTemp(data.tps1);
}
```

## Calibration

Default divisors assume: 1mΩ shunt, 4×300KΩ + 510Ω divider.

```cpp
// Read raw, divide by known actual value
uint32_t raw_v = meter.readReg(BL0940_REG_V_RMS);
float v_div = (float)raw_v / actual_voltage_from_meter;
meter.setVoltageDiv(v_div);
```

The IC also has hardware offset correction:
```cpp
meter.setCurrentOffset(offset);  // I_RMSOS register
meter.setPowerOffset(offset);    // WATTOS register
```

See the `Calibration` example for a complete walkthrough.

## API Reference

### Constructors

| Constructor | Description |
|-------------|-------------|
| `BL0940(Stream &serial)` | UART mode |
| `BL0940(int8_t csPin, uint32_t clock)` | SPI mode |

### Measurement Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `getVoltage()` | float (V) | RMS voltage |
| `getCurrent()` | float (A) | RMS current |
| `getPower()` | float (W) | Active power (signed) |
| `getEnergy()` | float (kWh) | Accumulated energy |
| `getFastCurrent()` | float (A) | Fast RMS current |
| `getPhaseAngle()` | float (deg) | V-I phase angle |
| `getPowerFactor()` | float | cos(phi) |
| `getInternalTemp()` | float (C) | IC temperature |
| `getExternalTemp()` | float (V) | External NTC ADC voltage |

### Full Packet

| Method | Description |
|--------|-------------|
| `readAll(BL0940_Data &data)` | Read all values in one packet (35 bytes) |
| `convertVoltage(raw)` | Convert raw to Volts |
| `convertCurrent(raw)` | Convert raw to Amps |
| `convertPower(raw)` | Convert raw to Watts |
| `convertEnergy(raw)` | Convert raw to kWh |
| `convertInternalTemp(raw)` | Convert raw to degrees C |

### Configuration

| Method | Description |
|--------|-------------|
| `setMode(mode)` | Write MODE register directly |
| `setACFreq60Hz(bool)` | Switch between 50/60 Hz |
| `setRMSUpdateRate(bool)` | 400ms (false) or 800ms (true) |
| `setOverCurrentThreshold(th)` | Fast RMS threshold |
| `setTempConfig(config)` | Temperature sensor config |
| `setCurrentOffset(offset)` | Hardware I_RMS offset |
| `setPowerOffset(offset)` | Hardware WATT offset |
| `setCreepThreshold(th)` | Anti-creep power threshold |

### Calibration

| Method | Description |
|--------|-------------|
| `setVoltageDiv(div)` | Voltage conversion divisor |
| `setCurrentDiv(div)` | Current conversion divisor |
| `setPowerDiv(div)` | Power conversion divisor |
| `setEnergyFactor(f)` | Energy per pulse (kWh) |

### Utility

| Method | Description |
|--------|-------------|
| `begin()` | Initialize (call in setup) |
| `softReset()` | Reset IC |
| `readReg(addr)` | Read raw 24-bit register |
| `writeReg(addr, data)` | Write register (auto-unlocks) |
| `lastReadOk()` | Check last communication success |

## BL0940 vs BL0942 vs BL0939

| Feature | BL0939 | BL0940 | BL0942 |
|---------|--------|--------|--------|
| Channels | 2 (A+B) | 1 | 1 |
| Interface | SPI/UART | SPI/UART | SPI/UART |
| Temperature | Yes (2x) | Yes (int+ext) | No |
| Phase Angle | No | Yes | No |
| Power Factor | No | Yes | No |
| Baud Rate | 4800 fixed | 4800 fixed | 4800-38400 |
| PGA Gain | Fixed | Fixed | 1x/4x/16x/24x |

## License

MIT License
