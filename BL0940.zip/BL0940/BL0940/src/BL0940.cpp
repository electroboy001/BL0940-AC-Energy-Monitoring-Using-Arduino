/**
 * @file BL0940.cpp
 * @brief Arduino library implementation for BL0940 energy metering IC
 */

#include "BL0940.h"

// ============================================================================
// Default calibration divisors for typical circuit:
//   Shunt: 1mOhm, Voltage divider: 4x300K series + 510R to GND
//   (Adjust these for your actual circuit)
//
// Formulas from datasheet:
//   V(V) = raw_V * Vref / (79931 * R_low / (R_high + R_low) * 1000)
//   I(A) = raw_I * Vref / (324004 * RL * 1000)
//   P(W) = raw_P * Vref^2 * (R_high + R_low) / (4046 * RL * R_low * 1e6)
//
// For 1mOhm shunt, 4x300K (1.2M total) + 510R:
//   voltage_div = 79931 * 510 / (1.218 * (1200000+510)) = 40764810/1461810 ≈ 27885
//   Actually simpler: V = raw / div, so div = raw_at_known_V / V
//   Using formula: V(V) = raw * 1.218 / (79931 * 510 / (1200510))
//                       = raw * 1.218 * 1200510 / (79931 * 510)
//                       = raw * 1461981.18 / 40764810
//                       = raw / 27885.6
//   No wait: V(V) = raw * Vref / (V_RMS_FACTOR)... that's the normalized formula
//   The datasheet says: V_RMS = 79931 * V(V) / Vref
//   So: V(V) = raw * Vref / 79931... but that's the ADC input voltage.
//   For actual mains: V_actual = V_adc * (R_high + R_low) / R_low
//   So: V_actual = raw * Vref * (R_high + R_low) / (79931 * R_low)
//   voltage_div = 79931 * R_low / (Vref * (R_high + R_low))
//               = 79931 * 510 / (1.218 * 1200510)
//               = 40764810 / 1462221.18 ≈ 27878.5
//
// For current: I(A) = raw * Vref / (324004 * RL * 1000)
//   Where RL = 0.001 ohm
//   current_div = 324004 * 0.001 * 1000 / 1.218 = 324.004 / 1.218 ≈ 266.0
//
// For power: P(W) = raw * Vref^2 * (R1+R2) / (4046 * RL * R2 * 1e6)
//   power_div = 4046 * 0.001 * 510 * 1e6 / (1.218^2 * 1200510)
//             = 2063460000 / 1781466.7 ≈ 1158.2
//
// Energy per pulse:
//   energy_per_pulse = Vref^2 * (R1+R2) / (3600000 * 4046 * RL * R2 * 1e6 / (1638.4*256))
//   meter_const = 3600000 * power_div_raw / (1638.4 * 256) where power_div_raw = 4046*RL*R2*1e6/(Vref^2*(R1+R2))
//   Simplified: energy_per_pulse ≈ 1 / (meter_const) kWh
// ============================================================================

// Default divisors for: 1mOhm shunt, 4x300K+510R divider
#define BL0940_DEF_VOLTAGE_DIV   27878.5f
#define BL0940_DEF_CURRENT_DIV   266.0f
#define BL0940_DEF_POWER_DIV     1158.2f
#define BL0940_DEF_ENERGY_KWH    0.0001264f

// ============================================================================
// Constructors
// ============================================================================

BL0940::BL0940(Stream &serial)
    : _commMode(BL0940_COMM_UART),
      _serial(&serial),
      _csPin(-1),
      _spiClock(0),
      _lastReadOk(false),
      _voltageDiv(BL0940_DEF_VOLTAGE_DIV),
      _currentDiv(BL0940_DEF_CURRENT_DIV),
      _powerDiv(BL0940_DEF_POWER_DIV),
      _energyKwh(BL0940_DEF_ENERGY_KWH)
{
}

BL0940::BL0940(int8_t csPin, uint32_t spiClock)
    : _commMode(BL0940_COMM_SPI),
      _serial(nullptr),
      _csPin(csPin),
      _spiClock(spiClock),
      _lastReadOk(false),
      _voltageDiv(BL0940_DEF_VOLTAGE_DIV),
      _currentDiv(BL0940_DEF_CURRENT_DIV),
      _powerDiv(BL0940_DEF_POWER_DIV),
      _energyKwh(BL0940_DEF_ENERGY_KWH)
{
}

// ============================================================================
// Initialization
// ============================================================================

bool BL0940::begin(void)
{
    if (_commMode == BL0940_COMM_SPI) {
        if (_csPin >= 0) {
            pinMode(_csPin, OUTPUT);
            _csHigh();
        }
        _spiSettings = SPISettings(_spiClock, MSBFIRST, SPI_MODE1);
        SPI.begin();
    }

    delay(50);
    softReset();
    delay(100);

    // Verify communication by reading TPS1 register
    uint32_t tps = readReg(BL0940_REG_TPS1);
    if (tps == BL0940_READ_ERROR) {
        return false;
    }

    return true;
}

// ============================================================================
// Calibration Setters
// ============================================================================

void BL0940::setVoltageDiv(float div)   { _voltageDiv = div; }
void BL0940::setCurrentDiv(float div)   { _currentDiv = div; }
void BL0940::setPowerDiv(float div)     { _powerDiv = div; }
void BL0940::setEnergyFactor(float f)   { _energyKwh = f; }

// ============================================================================
// High-level Readings
// ============================================================================

float BL0940::getVoltage(void)
{
    uint32_t raw = readReg(BL0940_REG_V_RMS);
    if (raw == BL0940_READ_ERROR) return -1.0f;
    return (float)raw / _voltageDiv;
}

float BL0940::getCurrent(void)
{
    uint32_t raw = readReg(BL0940_REG_I_RMS);
    if (raw == BL0940_READ_ERROR) return -1.0f;
    return (float)raw / _currentDiv;
}

float BL0940::getPower(void)
{
    uint32_t raw = readReg(BL0940_REG_WATT);
    if (raw == BL0940_READ_ERROR) return -1.0f;
    int32_t signed_val = _signExtend24(raw);
    return (float)signed_val / _powerDiv;
}

float BL0940::getEnergy(void)
{
    uint32_t raw = readReg(BL0940_REG_CF_CNT);
    if (raw == BL0940_READ_ERROR) return -1.0f;
    return (float)raw * _energyKwh;
}

float BL0940::getFastCurrent(void)
{
    uint32_t raw = readReg(BL0940_REG_I_FAST_RMS);
    if (raw == BL0940_READ_ERROR) return -1.0f;
    return (float)raw / _currentDiv;
}

float BL0940::getPhaseAngle(void)
{
    uint32_t raw = readReg(BL0940_REG_CORNER);
    if (raw == BL0940_READ_ERROR) return -1.0f;
    uint16_t corner = (uint16_t)(raw & 0xFFFF);
    // Phase angle = 2*PI * CORNER * fc / f0
    // fc = 50Hz (default), f0 = 1MHz (sampling frequency)
    // Convert to degrees: angle_deg = 360 * CORNER * 50 / 1000000
    //                                = CORNER * 0.018
    return (float)corner * 0.018f;
}

float BL0940::getPowerFactor(void)
{
    float angle = getPhaseAngle();
    if (angle < 0) return -1.0f;
    // Convert degrees to radians and compute cos
    float radians = angle * 3.14159265f / 180.0f;
    return cos(radians);
}

// ============================================================================
// Temperature
// ============================================================================

float BL0940::getInternalTemp(void)
{
    uint32_t raw = readReg(BL0940_REG_TPS1);
    if (raw == BL0940_READ_ERROR) return -999.0f;
    return convertInternalTemp((uint16_t)(raw & 0x03FF));
}

float BL0940::getExternalTemp(void)
{
    uint32_t raw = readReg(BL0940_REG_TPS2);
    if (raw == BL0940_READ_ERROR) return -999.0f;
    // External temp is raw ADC value (10-bit)
    // Voltage = raw * Vref / 1024
    // Actual temperature depends on NTC circuit - return raw ADC voltage
    uint16_t adc = (uint16_t)(raw & 0x03FF);
    return (float)adc * BL0940_VREF / 1024.0f;
}

// ============================================================================
// Full Packet Read (command: 0x58 + address 0xAA)
// Response: 35 bytes total
// [0x55] [I_FAST_RMS 3B] [I_RMS 3B] [reserved 3B] [V_RMS 3B] [reserved 3B]
// [WATT 3B] [reserved 3B] [CF_CNT 3B] [reserved 3B]
// [TPS1_L] [TPS1_H] [0x00] [TPS2_L] [TPS2_H] [0x00] [CHECKSUM]
// ============================================================================

bool BL0940::readAll(BL0940_Data &data)
{
    data.valid = false;

    if (_commMode == BL0940_COMM_UART) {
        if (_serial == nullptr) return false;

        _flushSerial();

        // Send read command with address 0xAA
        uint8_t cmd[2] = { BL0940_READ_CMD, BL0940_READ_ALL_ADDR };
        _serial->write(cmd, 2);

        // Wait for 35-byte response (takes ~77ms at 4800 baud)
        unsigned long start = millis();
        while (_serial->available() < BL0940_FULL_PACKET_SIZE) {
            if (millis() - start > 500) {
                _lastReadOk = false;
                return false;
            }
            delay(1);
        }

        uint8_t buf[BL0940_FULL_PACKET_SIZE];
        for (int i = 0; i < BL0940_FULL_PACKET_SIZE; i++) {
            buf[i] = _serial->read();
        }

        // Verify header
        if (buf[0] != BL0940_RESP_HDR) {
            // Sometimes header is 0x58 per datasheet
            if (buf[0] != BL0940_READ_CMD) {
                _lastReadOk = false;
                return false;
            }
        }

        // Verify checksum (sum of bytes 0..33, inverted)
        uint8_t sum = 0;
        for (int i = 0; i < 34; i++) {
            sum += buf[i];
        }
        sum = ~sum;
        if (sum != buf[34]) {
            _lastReadOk = false;
            return false;
        }

        // Parse data (UART = LSB first)
        // Byte layout per datasheet:
        // [0]: Header (0x55 or 0x58)
        // [1-3]: I_FAST_RMS (L, M, H)
        // [4-6]: I_RMS (L, M, H)
        // [7-9]: reserved
        // [10-12]: V_RMS (L, M, H)
        // [13-15]: reserved
        // [16-18]: WATT (L, M, H)
        // [19-21]: reserved
        // [22-24]: CF_CNT (L, M, H)
        // [25-27]: reserved
        // [28-30]: TPS1 (TPS1_L, TPS1_H, 0x00)
        // [31-33]: TPS2 (TPS2_L, TPS2_H, 0x00)
        // [34]: Checksum

        data.i_fast_rms = (uint32_t)buf[1] | ((uint32_t)buf[2] << 8) | ((uint32_t)buf[3] << 16);
        data.i_rms      = (uint32_t)buf[4] | ((uint32_t)buf[5] << 8) | ((uint32_t)buf[6] << 16);
        data.v_rms      = (uint32_t)buf[10] | ((uint32_t)buf[11] << 8) | ((uint32_t)buf[12] << 16);

        uint32_t watt_raw = (uint32_t)buf[16] | ((uint32_t)buf[17] << 8) | ((uint32_t)buf[18] << 16);
        data.watt = _signExtend24(watt_raw);

        data.cf_cnt = (uint32_t)buf[22] | ((uint32_t)buf[23] << 8) | ((uint32_t)buf[24] << 16);
        data.tps1   = (uint16_t)buf[28] | ((uint16_t)buf[29] << 8);
        data.tps2   = (uint16_t)buf[31] | ((uint16_t)buf[32] << 8);
        data.valid  = true;

        _lastReadOk = true;
        return true;

    } else {
        // SPI: read registers individually (no bulk packet in SPI mode)
        data.i_fast_rms = readReg(BL0940_REG_I_FAST_RMS);
        data.i_rms      = readReg(BL0940_REG_I_RMS);
        data.v_rms      = readReg(BL0940_REG_V_RMS);

        uint32_t watt_raw = readReg(BL0940_REG_WATT);
        data.watt = (watt_raw != BL0940_READ_ERROR) ? _signExtend24(watt_raw) : 0;

        data.cf_cnt = readReg(BL0940_REG_CF_CNT);

        uint32_t t1 = readReg(BL0940_REG_TPS1);
        uint32_t t2 = readReg(BL0940_REG_TPS2);
        data.tps1 = (t1 != BL0940_READ_ERROR) ? (uint16_t)(t1 & 0x03FF) : 0;
        data.tps2 = (t2 != BL0940_READ_ERROR) ? (uint16_t)(t2 & 0x03FF) : 0;

        data.valid = _lastReadOk;
        return data.valid;
    }
}

// ============================================================================
// Conversion Helpers
// ============================================================================

float BL0940::convertCurrent(uint32_t raw)   { return (float)raw / _currentDiv; }
float BL0940::convertVoltage(uint32_t raw)   { return (float)raw / _voltageDiv; }
float BL0940::convertPower(int32_t raw)      { return (float)raw / _powerDiv; }
float BL0940::convertEnergy(uint32_t raw)    { return (float)raw * _energyKwh; }

float BL0940::convertInternalTemp(uint16_t raw)
{
    // Formula: T(°C) = (170/448) * (TB/2 - 32) - 45
    float tb = (float)(raw & 0x03FF);
    return (170.0f / 448.0f) * (tb / 2.0f - 32.0f) - 45.0f;
}

// ============================================================================
// Configuration
// ============================================================================

void BL0940::setMode(uint32_t mode)
{
    _unlockWrite();
    writeReg(BL0940_REG_MODE, mode & 0xFFFF);
}

void BL0940::setACFreq60Hz(bool is60Hz)
{
    uint32_t mode = readReg(BL0940_REG_MODE);
    if (mode == BL0940_READ_ERROR) return;

    if (is60Hz)
        mode |= BL0940_MODE_AC_60HZ;
    else
        mode &= ~BL0940_MODE_AC_60HZ;

    _unlockWrite();
    writeReg(BL0940_REG_MODE, mode);
}

void BL0940::setRMSUpdateRate(bool slow800ms)
{
    uint32_t mode = readReg(BL0940_REG_MODE);
    if (mode == BL0940_READ_ERROR) return;

    if (slow800ms)
        mode |= BL0940_MODE_RMS_800MS;
    else
        mode &= ~BL0940_MODE_RMS_800MS;

    _unlockWrite();
    writeReg(BL0940_REG_MODE, mode);
}

void BL0940::setOverCurrentThreshold(uint16_t threshold)
{
    // I_FAST_RMS_CTRL: bit[15]=refresh mode, bits[14:0]=threshold
    uint32_t val = BL0940_FAST_FULL_CYCLE | (threshold & 0x7FFF);
    _unlockWrite();
    writeReg(BL0940_REG_I_FAST_CTRL, val);
}

void BL0940::setTempConfig(uint16_t config)
{
    _unlockWrite();
    writeReg(BL0940_REG_TPS_CTRL, (uint32_t)config);
}

void BL0940::setCurrentOffset(int8_t offset)
{
    _unlockWrite();
    writeReg(BL0940_REG_I_RMSOS, (uint32_t)(uint8_t)offset);
}

void BL0940::setPowerOffset(int8_t offset)
{
    _unlockWrite();
    writeReg(BL0940_REG_WATTOS, (uint32_t)(uint8_t)offset);
}

void BL0940::setCreepThreshold(uint8_t threshold)
{
    _unlockWrite();
    writeReg(BL0940_REG_WA_CREEP, (uint32_t)threshold);
}

// ============================================================================
// Raw Register Access
// ============================================================================

uint32_t BL0940::readReg(uint8_t addr)
{
    if (_commMode == BL0940_COMM_UART) {
        return _readRegUART(addr);
    } else {
        return _readRegSPI(addr);
    }
}

void BL0940::writeReg(uint8_t addr, uint32_t data)
{
    if (_commMode == BL0940_COMM_UART) {
        _writeRegUART(addr, data);
    } else {
        _writeRegSPI(addr, data);
    }
}

// ============================================================================
// Utility
// ============================================================================

void BL0940::softReset(void)
{
    _unlockWrite();
    writeReg(BL0940_REG_SOFT_RESET, BL0940_RESET_MAGIC);
}

bool BL0940::lastReadOk(void) const
{
    return _lastReadOk;
}

// ============================================================================
// UART Communication
// ============================================================================

uint32_t BL0940::_readRegUART(uint8_t addr)
{
    if (_serial == nullptr) {
        _lastReadOk = false;
        return BL0940_READ_ERROR;
    }

    _flushSerial();

    // Send: [0x58] [ADDR]
    uint8_t txBuf[2] = { BL0940_READ_CMD, addr };
    _serial->write(txBuf, 2);

    // Response: [Data_L] [Data_M] [Data_H] [Checksum]
    unsigned long start = millis();
    while (_serial->available() < 4) {
        if (millis() - start > 200) {
            _lastReadOk = false;
            return BL0940_READ_ERROR;
        }
        delay(1);
    }

    uint8_t b1 = _serial->read();  // Data_L
    uint8_t b2 = _serial->read();  // Data_M
    uint8_t b3 = _serial->read();  // Data_H
    uint8_t rxCS = _serial->read(); // Checksum

    // Checksum: ~(CMD + ADDR + Data_L + Data_M + Data_H) & 0xFF
    uint8_t calc = (BL0940_READ_CMD + addr + b1 + b2 + b3) & 0xFF;
    calc = ~calc;

    if (calc != rxCS) {
        _lastReadOk = false;
        return BL0940_READ_ERROR;
    }

    _lastReadOk = true;
    // UART: LSB first
    return ((uint32_t)b3 << 16) | ((uint32_t)b2 << 8) | (uint32_t)b1;
}

void BL0940::_writeRegUART(uint8_t addr, uint32_t data)
{
    if (_serial == nullptr) return;

    uint8_t b1 = data & 0xFF;          // Data_L
    uint8_t b2 = (data >> 8) & 0xFF;   // Data_M
    uint8_t b3 = (data >> 16) & 0xFF;  // Data_H

    uint8_t cs = (BL0940_WRITE_CMD + addr + b1 + b2 + b3) & 0xFF;
    cs = ~cs;

    uint8_t txBuf[6];
    txBuf[0] = BL0940_WRITE_CMD;
    txBuf[1] = addr;
    txBuf[2] = b1;  // Data_L first in UART
    txBuf[3] = b2;
    txBuf[4] = b3;
    txBuf[5] = cs;

    _serial->write(txBuf, 6);
    delay(5);
}

// ============================================================================
// SPI Communication
// ============================================================================

uint32_t BL0940::_readRegSPI(uint8_t addr)
{
    SPI.beginTransaction(_spiSettings);
    _csLow();

    SPI.transfer(BL0940_READ_CMD);
    SPI.transfer(addr);

    uint8_t b1 = SPI.transfer(0x00);  // Data_H (MSB first in SPI)
    uint8_t b2 = SPI.transfer(0x00);  // Data_M
    uint8_t b3 = SPI.transfer(0x00);  // Data_L
    uint8_t rxCS = SPI.transfer(0x00);

    _csHigh();
    SPI.endTransaction();

    // Checksum: ~(CMD + ADDR + b1 + b2 + b3) & 0xFF
    uint8_t calc = (BL0940_READ_CMD + addr + b1 + b2 + b3) & 0xFF;
    calc = ~calc;

    if (calc != rxCS) {
        _lastReadOk = false;
        return BL0940_READ_ERROR;
    }

    _lastReadOk = true;
    // SPI: MSB first
    return ((uint32_t)b1 << 16) | ((uint32_t)b2 << 8) | (uint32_t)b3;
}

void BL0940::_writeRegSPI(uint8_t addr, uint32_t data)
{
    uint8_t b1 = (data >> 16) & 0xFF;  // Data_H
    uint8_t b2 = (data >> 8) & 0xFF;   // Data_M
    uint8_t b3 = data & 0xFF;          // Data_L

    uint8_t cs = (BL0940_WRITE_CMD + addr + b1 + b2 + b3) & 0xFF;
    cs = ~cs;

    SPI.beginTransaction(_spiSettings);
    _csLow();

    SPI.transfer(BL0940_WRITE_CMD);
    SPI.transfer(addr);
    SPI.transfer(b1);
    SPI.transfer(b2);
    SPI.transfer(b3);
    SPI.transfer(cs);

    _csHigh();
    SPI.endTransaction();
}

// ============================================================================
// Private Helpers
// ============================================================================

int32_t BL0940::_signExtend24(uint32_t raw)
{
    if (raw & 0x800000)
        return (int32_t)(raw | 0xFF000000);
    return (int32_t)raw;
}

void BL0940::_csLow(void)
{
    if (_csPin >= 0) digitalWrite(_csPin, LOW);
}

void BL0940::_csHigh(void)
{
    if (_csPin >= 0) digitalWrite(_csPin, HIGH);
}

void BL0940::_flushSerial(void)
{
    if (_serial == nullptr) return;
    while (_serial->available()) {
        _serial->read();
    }
}

void BL0940::_unlockWrite(void)
{
    writeReg(BL0940_REG_USR_WRPROT, BL0940_WRPROT_UNLOCK);
}
