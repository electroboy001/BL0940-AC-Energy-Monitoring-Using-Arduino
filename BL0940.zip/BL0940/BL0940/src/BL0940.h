/**
 * @file BL0940.h
 * @brief Arduino library for BL0940 single-phase energy metering IC
 * @version 1.0.0
 *
 * Supports both UART and SPI communication modes.
 * UART mode is default (SEL pin LOW).
 *
 * Features: V/I/P/E measurement, temperature (internal + external),
 * phase angle, over-current detection, anti-creep.
 *
 * Typical circuit: 1mOhm shunt, voltage divider to VP/VN pins
 */

#ifndef BL0940_H
#define BL0940_H

#include <Arduino.h>
#include <SPI.h>

// ============================================================================
// Communication Commands
// ============================================================================

// UART/SPI frame bytes
#define BL0940_READ_CMD         0x58
#define BL0940_WRITE_CMD        0xA8
#define BL0940_READ_ALL_ADDR    0xAA    // Address for full packet read
#define BL0940_RESP_HDR         0x55    // Response header (full packet)

// ============================================================================
// Register Addresses
// ============================================================================

// Read-only electrical parameter registers
#define BL0940_REG_I_FAST_RMS   0x00    // Fast current RMS (24-bit unsigned)
#define BL0940_REG_I_WAVE       0x01    // Current waveform (24-bit signed)
#define BL0940_REG_V_WAVE       0x03    // Voltage waveform (24-bit signed)
#define BL0940_REG_I_RMS        0x04    // Current RMS (24-bit unsigned)
#define BL0940_REG_V_RMS        0x06    // Voltage RMS (24-bit unsigned)
#define BL0940_REG_WATT         0x08    // Active power (24-bit signed)
#define BL0940_REG_CF_CNT       0x0A    // Energy pulse counter (24-bit unsigned)
#define BL0940_REG_CORNER       0x0C    // Phase angle register (16-bit)
#define BL0940_REG_TPS1         0x0E    // Internal temperature (10-bit unsigned)
#define BL0940_REG_TPS2         0x0F    // External temperature (10-bit unsigned)

// Read/Write user registers
#define BL0940_REG_I_FAST_CTRL  0x10    // Fast RMS control (16-bit)
#define BL0940_REG_I_RMSOS      0x13    // Current RMS offset (8-bit signed)
#define BL0940_REG_WATTOS       0x15    // Active power offset (8-bit signed)
#define BL0940_REG_WA_CREEP     0x17    // Anti-creep threshold (8-bit)
#define BL0940_REG_MODE         0x18    // Mode register (16-bit)
#define BL0940_REG_SOFT_RESET   0x19    // Software reset (write 0x5A5A5A)
#define BL0940_REG_USR_WRPROT   0x1A    // Write protection (write 0x55 to unlock)
#define BL0940_REG_TPS_CTRL     0x1B    // Temperature control (16-bit)
#define BL0940_REG_TPS2_A       0x1C    // External temp gain coefficient (8-bit)
#define BL0940_REG_TPS2_B       0x1D    // External temp offset coefficient (8-bit)

// ============================================================================
// Constants
// ============================================================================

#define BL0940_RESET_MAGIC      0x5A5A5A
#define BL0940_WRPROT_UNLOCK    0x55
#define BL0940_READ_ERROR       0xFFFFFFFF

// Internal reference voltage
#define BL0940_VREF             1.218f

// Datasheet scaling factors
#define BL0940_I_RMS_FACTOR     324004.0f
#define BL0940_V_RMS_FACTOR     79931.0f
#define BL0940_WATT_FACTOR      4046.0f
#define BL0940_ENERGY_CONST     (1638.4f * 256.0f)

// Full packet response size (35 bytes)
#define BL0940_FULL_PACKET_SIZE 35

// ============================================================================
// MODE Register (0x18) Bit Definitions
// ============================================================================

#define BL0940_MODE_RMS_800MS   (1 << 8)    // 0: 400ms, 1: 800ms RMS update
#define BL0940_MODE_AC_60HZ     (1 << 9)    // 0: 50Hz, 1: 60Hz
#define BL0940_MODE_CF_ALARM    (1 << 12)   // 0: energy pulse, 1: alarm on CF pin

// ============================================================================
// TPS_CTRL Register (0x1B) Bit Definitions
// ============================================================================

#define BL0940_TPS_OFF          (1 << 15)   // 0: temp on, 1: temp off
#define BL0940_TPS_ALARM_OC     (1 << 14)   // 0: temp alarm, 1: over-current alarm
#define BL0940_TPS_SEL_AUTO     (0x00 << 12) // Automatic
#define BL0940_TPS_SEL_INTERNAL (0x02 << 12) // Internal only
#define BL0940_TPS_SEL_EXTERNAL (0x03 << 12) // External only
#define BL0940_TPS_INT_50MS     (0x00 << 10) // 50ms interval
#define BL0940_TPS_INT_100MS    (0x01 << 10) // 100ms interval (default)
#define BL0940_TPS_INT_200MS    (0x02 << 10) // 200ms interval
#define BL0940_TPS_INT_400MS    (0x03 << 10) // 400ms interval

// ============================================================================
// I_FAST_RMS_CTRL Register (0x10) Bit Definitions
// ============================================================================

#define BL0940_FAST_FULL_CYCLE  (1 << 15)   // 0: half-cycle, 1: full-cycle refresh
// Bits [14:0] = threshold value (compare with I_FAST_RMS[23:9])

// ============================================================================
// Communication Mode Enum
// ============================================================================

enum BL0940_CommMode {
    BL0940_COMM_UART,
    BL0940_COMM_SPI
};

// ============================================================================
// Full Packet Data Structure (from 0xAA command)
// ============================================================================

struct BL0940_Data {
    uint32_t i_fast_rms;    // Fast current RMS
    uint32_t i_rms;         // Current RMS
    uint32_t v_rms;         // Voltage RMS
    int32_t  watt;          // Active power (signed)
    uint32_t cf_cnt;        // Energy counter
    uint16_t tps1;          // Internal temperature raw
    uint16_t tps2;          // External temperature raw
    bool     valid;
};

// ============================================================================
// BL0940 Class
// ============================================================================

class BL0940 {
public:
    // UART constructor
    BL0940(Stream &serial);

    // SPI constructor
    BL0940(int8_t csPin, uint32_t spiClock);

    // Initialization
    bool begin(void);

    // --- Calibration ---
    void setVoltageDiv(float div);
    void setCurrentDiv(float div);
    void setPowerDiv(float div);
    void setEnergyFactor(float factor);

    // --- High-level Readings ---
    float getVoltage(void);             // Volts RMS
    float getCurrent(void);             // Amps RMS
    float getPower(void);               // Watts (active, signed)
    float getEnergy(void);              // kWh
    float getFastCurrent(void);         // Amps (fast RMS)
    float getPhaseAngle(void);          // Degrees
    float getPowerFactor(void);         // cos(phi)

    // --- Temperature ---
    float getInternalTemp(void);        // Degrees C
    float getExternalTemp(void);        // Raw ADC voltage (or NTC conversion)

    // --- Full Packet Read ---
    bool readAll(BL0940_Data &data);

    // --- Conversion Helpers ---
    float convertCurrent(uint32_t raw);
    float convertVoltage(uint32_t raw);
    float convertPower(int32_t raw);
    float convertEnergy(uint32_t raw);
    float convertInternalTemp(uint16_t raw);

    // --- Configuration ---
    void setMode(uint32_t mode);
    void setACFreq60Hz(bool is60Hz);
    void setRMSUpdateRate(bool slow800ms);
    void setOverCurrentThreshold(uint16_t threshold);
    void setTempConfig(uint16_t config);
    void setCurrentOffset(int8_t offset);
    void setPowerOffset(int8_t offset);
    void setCreepThreshold(uint8_t threshold);

    // --- Raw Register Access ---
    uint32_t readReg(uint8_t addr);
    void     writeReg(uint8_t addr, uint32_t data);

    // --- Utility ---
    void softReset(void);
    bool lastReadOk(void) const;

private:
    BL0940_CommMode _commMode;

    // UART members
    Stream*  _serial;

    // SPI members
    int8_t      _csPin;
    uint32_t    _spiClock;
    SPISettings _spiSettings;

    // State
    bool  _lastReadOk;
    float _voltageDiv;
    float _currentDiv;
    float _powerDiv;
    float _energyKwh;

    // Internal helpers
    uint32_t _readRegUART(uint8_t addr);
    void     _writeRegUART(uint8_t addr, uint32_t data);
    uint32_t _readRegSPI(uint8_t addr);
    void     _writeRegSPI(uint8_t addr, uint32_t data);
    int32_t  _signExtend24(uint32_t raw);
    void     _csLow(void);
    void     _csHigh(void);
    void     _flushSerial(void);
    void     _unlockWrite(void);
};

#endif // BL0940_H
