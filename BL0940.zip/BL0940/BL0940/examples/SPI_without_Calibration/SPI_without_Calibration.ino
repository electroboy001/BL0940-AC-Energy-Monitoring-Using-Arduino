/**
 * BL0940 SPI Mode + SSD1306 OLED Display
 *
 * OLED: SSD1306 128x64 I2C
 *
 * Wiring (Arduino Uno/Nano):
 * --------------------------------
 * BL0940:
 *   SCLK   -> D13
 *   RX/SDI -> D11
 *   TX/SDO -> D12
 *   SEL    -> 3.3V
 *   VDD    -> 3.3V
 *   GND    -> GND
 *
 * OLED SSD1306:
 *   VCC -> 5V
 *   GND -> GND
 *   SDA -> A4
 *   SCL -> A5
 *
 * Required Libraries:
 *   - BL0940
 *   - Adafruit GFX
 *   - Adafruit SSD1306
 */

#include <SPI.h>
#include <Wire.h>
#include <BL0940.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// OLED settings
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
#define SCREEN_ADDRESS 0x3C

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// BL0940 object
BL0940 meter(-1, 500000);

void setup()
{
    Serial.begin(115200);

    // Initialize OLED
    if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
        Serial.println("SSD1306 allocation failed");
        while (1);
    }

    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);

    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("BL0940 Energy Meter");
    display.println("Initializing...");
    display.display();

    // Initialize BL0940
    if (!meter.begin()) {

        Serial.println("BL0940 not detected!");

        display.clearDisplay();
        display.setCursor(0, 0);
        display.println("BL0940 ERROR!");
        display.println("Check SPI wiring");
        display.println("SEL pin HIGH");
        display.display();

        while (1) {
            delay(1000);
        }
    }

    Serial.println("BL0940 initialized.");
}

void loop()
{
    float voltage = meter.getVoltage();
    float current = meter.getCurrent();
    float power   = meter.getPower();
    float energy  = meter.getEnergy();
    float temp    = meter.getInternalTemp();

    // Serial Monitor Output
    if (meter.lastReadOk()) {

        Serial.print("V=");
        Serial.print(voltage, 1);

        Serial.print("V  I=");
        Serial.print(current, 3);

        Serial.print("A  P=");
        Serial.print(power, 1);

        Serial.print("W  E=");
        Serial.print(energy, 4);

        Serial.print("kWh  T=");
        Serial.print(temp, 1);
        Serial.println("C");

        // OLED Display
        display.clearDisplay();

        display.setTextSize(2);

        display.setCursor(0, 0);
        display.print("V: ");
        display.print(voltage, 1);
        display.println("V");
        display.setTextSize(1);
        display.setCursor(0, 20);
        display.print("Current: ");
        display.print(current, 3);
        display.println("A");

        display.setCursor(0, 30);
        display.print("Power:   ");
        display.print(power, 1);
        display.println("W");

        display.setCursor(0, 40);
        display.print("Energy: ");
        display.print(energy, 4);
        display.println("kWh");

        display.setCursor(0, 50);
        display.print("Temp:   ");
        display.print(temp, 1);
        display.println(" C");

        display.display();

    } else {

        Serial.println("Read error!");

        display.clearDisplay();
        display.setCursor(0, 0);
        display.println("BL0940 Read Error!");
        display.display();
    }

    delay(1000);
}
