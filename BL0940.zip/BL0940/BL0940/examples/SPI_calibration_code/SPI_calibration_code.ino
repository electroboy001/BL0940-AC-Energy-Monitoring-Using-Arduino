/**
 * BL0940 SPI Calibration + SSD1306 OLED
 *
 * Uses SPI mode exactly like the main example
 * and displays calibration divisors on OLED.
 *
 * Wiring:
 * --------------------------------
 * BL0940:
 *   SCLK   -> D13
 *   RX/SDI -> D11
 *   TX/SDO -> D12
 *   SEL    -> 3.3V
 *   VDD    -> 3.3V
 *   GND    -> GND
 *
 * OLED SSD1306:
 *   SDA -> A4
 *   SCL -> A5
 *   VCC -> 5V
 *   GND -> GND
 */

#include <SPI.h>
#include <Wire.h>
#include <BL0940.h>

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------------- OLED ----------------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
#define SCREEN_ADDRESS 0x3C

Adafruit_SSD1306 display(
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    &Wire,
    OLED_RESET
);

// -------------- BL0940 SPI ----------------
// Same as main example
BL0940 meter(-1, 500000);

// ===== Reference Meter Values =====
const float ACTUAL_VOLTAGE = 249.0;
const float ACTUAL_CURRENT = 0.402;
const float ACTUAL_POWER   = 100.0;
// ===================================

void setup()
{
    Serial.begin(115200);

    // OLED Init
    if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {

        Serial.println("SSD1306 allocation failed");

        while (1);
    }

    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);

    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("BL0940 SPI");
    display.println("Calibration");
    display.println("Initializing...");
    display.display();

    // BL0940 Init (SPI)
    if (!meter.begin()) {

        Serial.println("BL0940 not detected!");

        display.clearDisplay();
        display.setCursor(0, 0);
        display.println("BL0940 ERROR!");
        display.println("Check SPI");
        display.println("SEL HIGH");
        display.display();

        while (1) {
            delay(1000);
        }
    }

    Serial.println("BL0940 initialized.");

    // Stabilization delay
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("Wait...");
    display.println("Stabilizing");
    display.display();

    delay(3000);

    // Read raw registers
    uint32_t raw_v = meter.readReg(BL0940_REG_V_RMS);
    uint32_t raw_i = meter.readReg(BL0940_REG_I_RMS);
    uint32_t raw_p = meter.readReg(BL0940_REG_WATT);

    // Calculate divisors
    float voltage_div = (float)raw_v / ACTUAL_VOLTAGE;
    float current_div = (float)raw_i / ACTUAL_CURRENT;
    float power_div   = (float)raw_p / ACTUAL_POWER;

    // Serial Output
    Serial.println();
    Serial.println("=== Calibration Divisors ===");

    Serial.print("meter.setVoltageDiv(");
    Serial.print(voltage_div, 1);
    Serial.println(");");

    Serial.print("meter.setCurrentDiv(");
    Serial.print(current_div, 1);
    Serial.println(");");

    Serial.print("meter.setPowerDiv(");
    Serial.print(power_div, 1);
    Serial.println(");");

    // OLED Output
    display.clearDisplay();

    display.setTextSize(2);

    display.setCursor(0, 0);
    display.println("Calibrate");

    display.setTextSize(1);
    display.setCursor(0, 20);
    display.print("VDiv:");
    display.println(voltage_div, 1);

    display.setCursor(0, 36);
    display.print("IDiv:");
    display.println(current_div, 1);

    display.setCursor(0, 52);
    display.print("PDiv:");
    display.println(power_div, 1);

    display.display();
}

void loop()
{
    // Nothing required
}
