/**
 * BL0940 Full Packet Read Example (UART Mode)
 *
 * Uses the 0x58+0xAA command to read all measurements in a single
 * 35-byte packet. More efficient than individual register reads.
 *
 * Packet includes: I_FAST_RMS, I_RMS, V_RMS, WATT, CF_CNT, TPS1, TPS2
 *
 * Wiring: Same as BasicReading example.
 */

#include <BL0940.h>

#include <SoftwareSerial.h>
SoftwareSerial blSerial(2, 3);  // RX=D2, TX=D3

BL0940 meter(blSerial);

void setup()
{
    Serial.begin(115200);
    while (!Serial) { ; }

    Serial.println("BL0940 - Full Packet Reading");
    Serial.println("==============================");

    blSerial.begin(4800);

    if (!meter.begin()) {
        Serial.println("ERROR: BL0940 not found!");
        while (1) { delay(1000); }
    }

    Serial.println("Ready. Reading full packets...\n");
}

void loop()
{
    BL0940_Data data;

    if (meter.readAll(data)) {
        float voltage   = meter.convertVoltage(data.v_rms);
        float current   = meter.convertCurrent(data.i_rms);
        float fastI     = meter.convertCurrent(data.i_fast_rms);
        float power     = meter.convertPower(data.watt);
        float energy    = meter.convertEnergy(data.cf_cnt);
        float tempInt   = meter.convertInternalTemp(data.tps1);

        Serial.println("--- Measurement ---");
        Serial.print("  Voltage:      "); Serial.print(voltage, 1);  Serial.println(" V");
        Serial.print("  Current:      "); Serial.print(current, 3);  Serial.println(" A");
        Serial.print("  Fast Current: "); Serial.print(fastI, 3);    Serial.println(" A");
        Serial.print("  Power:        "); Serial.print(power, 1);    Serial.println(" W");
        Serial.print("  Energy:       "); Serial.print(energy, 4);   Serial.println(" kWh");
        Serial.print("  Temp (IC):    "); Serial.print(tempInt, 1);  Serial.println(" C");
        Serial.println();

        // Raw values for debugging
        Serial.print("  [RAW] I_RMS=0x"); Serial.print(data.i_rms, HEX);
        Serial.print(" V_RMS=0x"); Serial.print(data.v_rms, HEX);
        Serial.print(" WATT=0x"); Serial.print((uint32_t)data.watt & 0xFFFFFF, HEX);
        Serial.print(" TPS1="); Serial.println(data.tps1);
        Serial.println();
    } else {
        Serial.println("ERROR: Full packet read failed!");
    }

    delay(2000);
}
